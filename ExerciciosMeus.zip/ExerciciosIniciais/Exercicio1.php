<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
    <title> Exercicio1 </title>
</head>
<body>

<?php
$sumando1=1;
$sumando2=5;
$resultado=$sumando1+$sumando2;
print "La suma de $sumando1 + $sumando2= $resultado"
?>
</body>
</html>