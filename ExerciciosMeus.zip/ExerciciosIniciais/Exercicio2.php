<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
    <title> Exercicio2 </title>
</head>
<body>

<?php
    $numero = 0;

    while($numero<10){
        $numero++;
        echo $numero;
    }

?>
<br>
<?php
     $numero2 = 0;
    for($i=0;$i<10;$i++){
        $numero2++;
        echo $numero2;
    }
?>

</body>
</html>