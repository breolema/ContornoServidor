<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
    <title> Exercicio3 </title>
</head>
<body>

<?php
$ruta = "img/logo.png";
?>

<img src="<?php echo $ruta; ?>" >

</body>
</html>