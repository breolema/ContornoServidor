<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
    <title> titulo da paxina </title>
</head>
<body>

<?php
  $n1=17;
  $n2=175;

  //podemos usar un sistema de numeracion distinto do decimal.
  $octal=071;
  echo $octal;  //vai escribir 56, que ven sendo 71 en decimal.
  echo "<br>";
  //podes usar hexademimal
  $hexa=0xA2BC;
  echo $hexa; //vai escribir o numeero 41160 que é equivalente a A2BC en hexadecinal
  echo "<br>";



?>



</body>
</html>