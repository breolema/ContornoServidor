<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
    <title> titulo da paxina </title>
</head>
<body>

<?php
//do while...
 $i=0;

 do {
    $i++;
    echo $i."<br />";
 } while ($i<100);


$i=0;
$i++;
echo $i."<br/>";
//facer un do while ou un while, ven sendo case o mesmo...


?>


</body>
</html>
