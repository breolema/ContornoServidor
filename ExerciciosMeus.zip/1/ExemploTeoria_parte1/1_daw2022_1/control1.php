<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
    <title> titulo da paxina </title>
</head>
<body>

<?php
 //ESTRUCTURAS DE CONTROL condicional simple
 /**
  * IF (expresionlogica) { instruccións}
  */
/**
 * IF (expresionlogica)
 * instruccoion;
 */
$aprobados=0;
$nota=6;
if ($nota>=5){
    echo "aprobado";
    $aprobados++;
}
/**
 * if (expresión_logica):
 * instrucciones
 * ......
 * endif;
 */

?>

</body>
</html>
