<!doctype html>
<html lang="es">
    <head>
        <meta charset="utf-8"/>
        <title> titulo da paxina </title>
</head>
<body>

<?php
   echo "ola mundo";
?>



</body>
</html>