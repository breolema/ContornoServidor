<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
    <title> titulo da paxina </title>
</head>
<body>

<?php
//php fai cousas moi raras cando se suman variables de disntos tipos...
$v1=18;
$v2="3 de decembro";
echo $v1+$v2;
echo "<br>";
//vai escribir 21, xa que entende que se queren sumar os numeros 18 e 3...

$x=2.5;
$y=4;
$z=(int)$x * $y;
//$z vai valer 8, o que facemos con (int) e castear o resultado...



?>



</body>
</html>