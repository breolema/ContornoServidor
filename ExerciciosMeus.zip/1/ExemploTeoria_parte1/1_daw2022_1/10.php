<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
    <title> titulo da paxina </title>
</head>
<body>

<?php
   // as variables poden usarse sen inicializarse
   echo $x; //vai dar erro porque non ten valor esa variable.
   $y=$x+2; //darra erro porque non está definida.

?>



</body>
</html>