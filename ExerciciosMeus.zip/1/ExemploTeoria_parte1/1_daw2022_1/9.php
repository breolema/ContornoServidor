<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
    <title> titulo da paxina </title>
</head>
<body>

<?php
   // as variables poden usarse sen inicializarse
   $edad=15;
   //para pintar o valor
   echo $edad;
   echo "<br>";
   $edad="maximino romero";
   echo $edad;

   $x=12;
   $nome="toni";
   $gastos=1000;
   $ingresos=1200;
   $beneficios=($gastos-$ingresos)*0.6;  
   echo "<br>";
   echo $beneficios; 



?>



</body>
</html>