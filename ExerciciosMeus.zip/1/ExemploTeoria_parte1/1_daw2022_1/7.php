<!doctype html>
<html lang="es">
    <head>
        <meta charset="utf-8"/>
        <title> titulo da paxina </title>
</head>
<body>

<?php
   echo "ola mundo";  #aquí meto un anaco de comentario
   echo "agora poñemos algo en <strong> de cor negrita </strong>";
   /* aprobeito para por uns comentarios
   de varias liñas
   */
   echo "acabouse"; //tamen podo por así o comentario.
?>



</body>
</html>