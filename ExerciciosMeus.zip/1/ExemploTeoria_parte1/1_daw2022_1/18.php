<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
    <title> titulo da paxina </title>
</head>
<body>

<?php
 //operadores de asignación.
 $y=3;
 $x=$y+9.8;
 //$x vale 12.8
 echo $x;
 echo "<br>";

 $x+=3; //esto é o meso que facer $x=$x+3;
 echo $x;
 echo "<br>";

 $x++; //é equivalente a facer $x=$x+1;
 echo $x;
 echo "<br>";
 $x--; //é equivalente a facer $x=$x-1;
 echo $x;
 echo "<br>";
 



?>



</body>
</html>
