<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
    <title> titulo da paxina </title>
</head>
<body>

<?php
//bucle for...
/**
 * ----- for (inicialización; condicion;incremento){
 * sentenzas
 * }
 * ------ for (inicialización; condicion; incremento){
 * sentencias
 * endfor}
 */
 

 for ($i=1; $i<=1000; $i++){
    echo $i."<br/>";
 }

//o for anterior é equivalente a facer un while...
$i=1;
while ($i<=100){
    echo $i."<br/>";
    $i++;
}


?>


</body>
</html>
