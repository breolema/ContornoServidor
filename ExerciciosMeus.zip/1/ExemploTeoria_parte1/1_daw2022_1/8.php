<!doctype html>
<html lang="es">
    <head>
        <meta charset="utf-8"/>
        <title> titulo da paxina </title>
</head>
<body>

<?php
   echo "Primeiro texto ", "agora o segundo texto a ver que pasa";
   echo "<br>";  //meto un salto de liña.
?>

<?php
// aqui metemos outro anaco de php
// podes sustituir a palabra echo por ?= , isto é
?>

<?= "aqui escribo un texto", " e aui poño outro"
?>
print "este print saca todo como está xa que non existe como propiedade de html!!!!!!";
<?php 
//tamen se pode usar print para amosar por pantalla.
print "xa vai sendo  horas";
?>



</body>
</html>