<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
    <title> titulo da paxina </title>
</head>
<body>

<?php
$saludo = "Hola";         // Se define una variable
print "<p>$saludo</p>";   // Se escribe el valor de la variable
?>

<?php
$saludo = "Hola";             // Se define una variable
?>
<?php
print "<pre>$saludo<pre>";   // Se escribe el valor de la variable
?>

<?php
print "<p>Hola</p>\n";
print "<p>¿Cómo estás?</p>\n";
print "<p>Adios</p>\n";
?>

<p>Hola</p>
<?php
print "<p>¿Cómo estás?</p>\n";
print "<p>Adios</p>\n";
?>



</body>
</html>
