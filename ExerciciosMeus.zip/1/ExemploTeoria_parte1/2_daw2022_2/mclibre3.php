<?php
print "<!DOCTYPE html>\n";
print "<html lang=\"es\">\n";
print "<head>\n";
print "  <meta charset=\"utf-8\">\n";
print "  <title>Página HTML 5 válida</title>\n";
print "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n";
print "  <link rel=\"stylesheet\" href=\"estilo.css\" title=\"Color\">\n";
print "</head>\n";
print "\n";
print "<body>\n";
print "  <p>Esta página es una página HTML 5 válida.</p>\n";
print "</body>\n";
print "</html>\n";
?>