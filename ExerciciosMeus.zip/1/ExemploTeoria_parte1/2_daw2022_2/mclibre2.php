<?php
print "<!DOCTYPE html>
<html lang=\"es\">
<head>
  <meta charset=\"utf-8\">
  <title>Página HTML 5 válida</title>
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
</head>

<body>
  <p>Esta página es una página HTML 5 válida.</p>
</body>
</html>";
?>
