<?php
print "<!DOCTYPE html>\n";
print "<html lang=\"es\"\n";
print "<head>\n";
print "<title> primeira paxina </title>\n";
print "</head>\n";
print "<body>\n";
print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
print "<p> <h1> hola mundo phpp </h1> </p>\n";
print "</body>\n";
print "</html>\n";
?>