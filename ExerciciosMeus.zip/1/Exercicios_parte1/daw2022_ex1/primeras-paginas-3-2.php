<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
      practica 3_2
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
<?php

print "  <p><h1> hola mundo </h1></p>\n";
print "<p><a href=\"primeras-paginas-3-1.php\"> volvemos ao principio </a>";

?>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
