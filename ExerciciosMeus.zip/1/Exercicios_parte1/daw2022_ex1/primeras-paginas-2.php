<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
         proba de paxinas sen formularios
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
<?php

print "  <p><h1> Ola mundo PHP </h1></p>\n";

?>

  <footer>
    <p>son eu e sempre o serei.</p>
  </footer>
</body>
</html>
