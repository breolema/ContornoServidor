<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
    <title> titulo da paxina </title>
</head>
<body>

<?php
//recolle os datos do formulario1 e pintaos...
print "<pre>";
print_r($_REQUEST);//$_REQUEST ten todos os valores recibidos do formulario
print "</pre>";
?>

</body>
</html>