<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
    <title> Exercicio 4</title>
    <style>
        body {
            background-color: <?php echo "rgb(" . rand(0, 255) . "," . rand(0, 255) . "," . rand(0, 255) . ")";?>
        }
</style>
</head>
<body>
<h1>Fondo aleatorio</h1>
</body>
</html>