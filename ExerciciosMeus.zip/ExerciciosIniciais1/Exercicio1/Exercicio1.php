<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
    <title> Exercicio1</title>
</head>
<body>
    
<?php
    $animal = rand(1, 2);

    print  "<p><img src=\"img/$animal.jpg\" alt=\"$animal\" width=\"280\" height=\"auto\"></p>";
    
?>

</body>
</html>