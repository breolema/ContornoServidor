<?php
setcookie("nome", false);
setcookie("apelidos", false);
setcookie("colorFondo", false);
setcookie("colorLetra", false);
setcookie("tipoLetra", false);

header("Location: practica1_index.php");
?>