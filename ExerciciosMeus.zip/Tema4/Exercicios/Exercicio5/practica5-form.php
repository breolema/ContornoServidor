<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Exercicio5</title>
</head>
<body>
    <h2>Escribe as palabras que te acordas</h2>
    <form method="post" action="">
        <p>Palabra 1: <input type="text" name="palabra1User"></p>
        <p>Palabra 2: <input type="text" name="palabra2User"></p>
        <p>Palabra 3: <input type="text" name="palabra3User"></p>
        <p>Palabra 4: <input type="text" name="palabra4User"></p>
        <p>Palabra 5: <input type="text" name="palabra5User"></p>
        <input type="submit" value="Comprobar">
    </form>
</body>
</html>