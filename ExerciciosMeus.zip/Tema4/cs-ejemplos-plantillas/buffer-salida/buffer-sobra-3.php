<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Buffer y redirecciones. Cabeceras. Ejemplos. PHP. Bartolomé Sintes Marco. www.mclibre.org</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <p>Esta es la página 3</p>

  <p>La redirección <strong>SÍ</strong> se ha realizado.</p>

  <p><a href="buffer-sobra-1.php">Volver al principio</a></p>
</body>
</html>
