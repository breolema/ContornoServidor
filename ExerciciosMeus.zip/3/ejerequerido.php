<?php
	echo "En el fichero requerido <br>";
	echo $a;
	echo $b;
