<?php
	for($i = 0; $i < 5; $i = $i + 1){
		echo "$i <br>";
	}