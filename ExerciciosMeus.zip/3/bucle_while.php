<?php
	$i = 0;
	while($i < 5){
		echo "$i <br>";
		$i = $i +1;
	}