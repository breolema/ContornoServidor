<?php
	function suma($a, $b)
	{   
		return $a + $b;
	}
	echo suma(4,8).'<br>';
	$var1 = 35;
	$var2 = 5;
	$var3 = suma($var1, $var2);
	echo $var3.'<br>';
